# Independent audit reproduction files

Run from the extracted Nov 15 project directory, with Python 3 and no extra dependencies for the scripts themselves. `pandas` is optional for summarizing CSV data.

- `stress_v2.py`: runs 2,700 new dark pricing/cost/leakage simulations; source file writes to `/tmp/roleproof_v2_stress_complete.csv`, using preconfigured `ROOT` pointing to the audit's sandbox. Change `ROOT` and target file if running elsewhere.
- `stress_complete.csv`: completed 2,700 original stress result records.
- `fee_stress.py`: 2,700 fee-cap/listing sensitivity cases; script writes `/tmp/roleproof_fee_stress.csv`; change `ROOT` for different filesystem layouts.
- `fee_stress.csv`: completed 2,700 fee-sweep records.
- `check_replay.py`: regenerates sampled runs and compares 10,626 fields against original package; uses preconfigured absolute `ROOT`.
- `replay.log`: output from the run-level comparison.
- `testv2.log`: six targeted v2 mechanics tests passed.
- `invariants_verify.log`: eight invariants passed.
- `verdict_verify.txt`: regenerated `v2_verdicts.py` output; byte-identical with originally provided `v2_verdicts.txt`.
- `unit_partial.log`: original 20-test suite **incomplete**, not proof of a pass.

Scripts are intentionally included verbatim with the tested module edits in `stress_v2.py`; that script tests changes to the seller bargaining split without altering the user's original file. A completed regression data table is provided separately to avoid relying on rerunning multi-process code.
