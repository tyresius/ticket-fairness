import sys,os,random,time,statistics as st,csv
from concurrent.futures import ProcessPoolExecutor
from collections import defaultdict
ROOT='/mnt/data/audit_v2_work/role-proof-final-audit-2026-11-15'
sys.path.insert(0,ROOT)
import gre_sim as baseline
from gre_sim import Rule,FAN_TYPES
from role_proof import agent_utility
from v2_experiment import channel_value,seed_for
import types
SOURCE=open(ROOT+'/gre_sim.py').read()
SOURCE2=SOURCE.replace('return (r + max(r, top_wtp)) / 2','return (0.25 * r + 0.75 * max(r, top_wtp))').replace('dark_price = round((reservation + buyer.def_["max_pay_mul"] * FACE) / 2)','dark_price = round((0.25 * reservation + 0.75 * buyer.def_["max_pay_mul"] * FACE))')
assert SOURCE!=SOURCE2 and '0.25 * reservation' in SOURCE2
more_for_seller=types.ModuleType('gre_sim_alt')
exec(compile(SOURCE2,'gre_sim_alt.py','exec'),more_for_seller.__dict__)

def job(arg):
 d,ix,s,scen=arg
 m= more_for_seller if scen=='seller75' else baseline
 kw={'secondary_fee_seller':0.05,'secondary_fee_buyer':0.05,'mechanics':'v2'}
 if scen=='lowercost':kw['scalper_dark_cost']=0.20
 if scen=='higherleak':kw['dark_leakage_base']=0.8
 outputs=[]
 for c in (0,10,20,30,40):
  random.seed(seed_for(ix,s))
  res=m.simulate(m.Rule('cap',c/100,4,None),d,return_agents=True,**kw)
  chan=channel_value(res)
  fans=[a for a in res['agents'] if a.type in FAN_TYPES]
  u=sum(agent_utility(a,res,0,proceeds=True,resale_override=chan) for a in fans)/len(fans)
  sc=[a for a in res['agents'] if a.type=='scalper']
  roi=res['outcomes']['scalper']['utility']; roi=(roi-0.3)/0.65 if roi>=0.3 else roi-0.3
  routed=res['dark_sold']+res['dark_unmatched'];listed=sum(a.resale_tickets for a in sc)
  outputs.append(dict(scenario=scen,demand=d,seed=s,cap=c,fan_B_P0=u,scalper_roi=roi,scalper_listed=listed,dark_routed=routed,dark_sold=res['dark_sold'],seats=res['attend']))
 return outputs

if __name__=='__main__':
 t=time.time(); LEVELS=[1.5,2,3,4,5,6,7,8,10]
 scenarios=['base','lowercost','seller75','higherleak']
 indices=[3,4,8]
 args=[(LEVELS[ix],ix,s,sc) for sc in scenarios for ix in indices for s in range(45)]
 out='/tmp/roleproof_v2_stress_complete.csv'
 n=0
 with ProcessPoolExecutor(max_workers=4) as pool,open(out,'w',newline='') as f:
  writer=None
  for rows in pool.map(job,args,chunksize=4):
   if writer is None:writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader()
   writer.writerows(rows); n+=len(rows)
 print('saved',n,'records','time',round(time.time()-t,2),'seconds')
