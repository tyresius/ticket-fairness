import csv,sys,random,statistics as st,math,os,time
from concurrent.futures import ProcessPoolExecutor
ROOT='/mnt/data/audit_v2_work/role-proof-final-audit-2026-11-15'
sys.path.insert(0,ROOT)
from gre_sim import simulate,Rule,FAN_TYPES
from role_proof import agent_utility
from v2_experiment import channel_value,seed_for
LEVELS=[1.5,2,3,4,5,6,7,8,10]
def calc(arg):
 ix,seed,fee,listing=arg
 d=LEVELS[ix]; out=[]
 for c in (0,10,20,30,40):
  random.seed(seed_for(ix,seed))
  res=simulate(Rule('cap',c/100,4,None),d,return_agents=True,mechanics='v2',fan_listing=listing,secondary_fee_seller=fee,secondary_fee_buyer=fee)
  channel=channel_value(res)
  fs=[a for a in res['agents'] if a.type in FAN_TYPES]
  u=sum(agent_utility(a,res,0,proceeds=True,resale_override=channel) for a in fs)/len(fs)
  v=res['outcomes']['scalper']['utility']; roi=(v-.3)/.65 if v>=.3 else v-.3
  out.append(dict(demand=d,seed=seed,fee=fee,listing=listing,cap=c,fan=u,roi=roi))
 return out
if __name__=='__main__':
 args=[(ix,s,fee,listing) for fee in (.02,.10) for listing in ('model','always') for ix in (2,4,8) for s in range(45)]
 t=time.time()
 with ProcessPoolExecutor(max_workers=4) as pool,open('/tmp/roleproof_fee_stress.csv','w',newline='') as f:
  writer=None
  for rows in pool.map(calc,args,chunksize=4):
   if not writer:writer=csv.DictWriter(f,list(rows[0]));writer.writeheader()
   writer.writerows(rows)
 print('wrote',len(args)*5,'records in',round(time.time()-t,2),'seconds')
