import sys,gzip,csv,os
ROOT='/mnt/data/audit_v2_work/role-proof-final-audit-2026-11-15'
sys.path.insert(0,ROOT)
from v2_experiment import run
p='/mnt/data/audit_v2_work/replayed.csv.gz'
count=run([0,4,8],2,p,verbose=False)
errors=[]; total=0
with gzip.open(p,'rt') as f:
 for row in csv.DictReader(f):
  d=float(row['demand']); ix={1.5:0,5:4,10:8}[d]
  source=ROOT+f'/v2-runs-{ix}.csv.gz'
  with gzip.open(source,'rt') as orig:
   matches=[rr for rr in csv.DictReader(orig) if rr['seed']==row['seed'] and rr['arm']==row['arm'] and rr['mechanics']==row['mechanics'] and rr['listing']==row['listing']]
  assert len(matches)==1
  orig=matches[0]; diffs={k:(row[k],orig[k]) for k in row if row[k]!=orig[k]}
  if diffs: errors.append((row['demand'],row['seed'],row['arm'],row['mechanics'],row['listing'],diffs))
  total+=1
print('replayed',count,'compared',total,'cells',total*len(row),'mismatched rows',len(errors)); print('first errors',errors[:3])
